document.getElementById("weather-form").addEventListener("submit", async function(e) {
  e.preventDefault();
  const city = document.getElementById("city").value.trim();
  const apiKey = "your_api_key_here"; // Replace with your OpenWeatherMap API key
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
  const resultBox = document.getElementById("weather-result");
  resultBox.innerHTML = "Loading...";
  
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error("City not found");
    const data = await response.json();
    const { name, main, weather } = data;
    const weatherHTML = `
      <h2>Weather in ${name}</h2>
      <p>Temperature: ${main.temp} °C</p>
      <p>Condition: ${weather[0].description}</p>
      <img src="https://openweathermap.org/img/wn/${weather[0].icon}@2x.png" alt="Weather icon" />
    `;
    resultBox.innerHTML = weatherHTML;
  } catch (error) {
    resultBox.innerHTML = `<p style="color:red;">${error.message}</p>`;
  }
});