# Weather App

## Description
A simple web app to get current weather information by city name using the OpenWeatherMap API.

## Features
- Enter a city to get temperature and weather conditions.
- Weather icon included.
- Error handling for invalid locations.
- Responsive design.

## Technologies Used
- HTML
- CSS
- JavaScript
- OpenWeatherMap API

## How to Run
1. Replace `your_api_key_here` in `script.js` with your API key from https://openweathermap.org/api.
2. Open `index.html` in a browser.
3. Enter a city name and click "Get Weather".